// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig : {
    apiKey: "AIzaSyCPbhPVKGAbYzSYS0txXGGKQ41O7JrTeIM",
    authDomain: "formadora-ii-b587b.firebaseapp.com",
    projectId: "formadora-ii-b587b",
    storageBucket: "formadora-ii-b587b.appspot.com",
    messagingSenderId: "873778657037",
    appId: "1:873778657037:web:207db6e28e74bbb06aa244",
    measurementId: "G-W46KDJX7KM"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
