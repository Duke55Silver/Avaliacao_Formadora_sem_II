import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { LoadingController } from '@ionic/angular';
import { AutheticationService } from 'src/app/authetication.service';

@Component({
  selector: 'app-cadastro',
  templateUrl: './cadastro.page.html',
  styleUrls: ['./cadastro.page.scss'],
})
export class CadastroPage implements OnInit {
  regForm: FormGroup

  constructor(public formBuilder:FormBuilder, public carregarcontroles: LoadingController, public authService:AutheticationService,public router: Router) { }

  ngOnInit() {
    this.regForm = this.formBuilder.group({
      nomecompleto:['', [Validators.required]],
      email:['', [
        Validators.required,
        Validators.email,
        Validators.pattern("[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$")
      ]],
      criarsenha:['',[
        Validators.required,
        Validators.pattern("(?=.*\d)(?=.*[a-z])(?=.*[0-8])(?=.*[A-Z]).{8,}")
      ]]
    })
  }

  get errorControl(){
    return this.regForm?.controls;
  }

  async cadastrar(){
    if (!this.regForm.valid) {
        console.log('Por favor, forneça valores corretos!');
        return;
    }

    const loading = await this.carregarcontroles.create();
    await loading.present();

    try {
        const user = await this.authService.cadastrar(this.regForm.value.email, this.regForm.value.criarsenha);
        if (user) {
            await loading.dismiss();
            this.router.navigate(['/home']);
        } else {
            console.log('Falha ao cadastrar usuário.');
            await loading.dismiss();
        }
    } catch (error) {
        console.error('Erro ao cadastrar:', error);
        await loading.dismiss();
    }
}
}
