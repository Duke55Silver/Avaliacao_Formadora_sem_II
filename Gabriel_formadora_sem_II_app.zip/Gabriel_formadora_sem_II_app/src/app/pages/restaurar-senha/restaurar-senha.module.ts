import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { RestaurarSenhaPageRoutingModule } from './restaurar-senha-routing.module';

import { RestaurarSenhaPage } from './restaurar-senha.page';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    RestaurarSenhaPageRoutingModule
  ],
  declarations: [RestaurarSenhaPage]
})
export class RestaurarSenhaPageModule {}
