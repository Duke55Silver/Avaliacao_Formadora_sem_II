import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { RestaurarSenhaPage } from './restaurar-senha.page';

const routes: Routes = [
  {
    path: '',
    component: RestaurarSenhaPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class RestaurarSenhaPageRoutingModule {}
