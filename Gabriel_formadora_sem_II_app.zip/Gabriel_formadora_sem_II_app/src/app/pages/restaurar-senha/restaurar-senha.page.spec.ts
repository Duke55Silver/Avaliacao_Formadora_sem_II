import { ComponentFixture, TestBed } from '@angular/core/testing';
import { RestaurarSenhaPage } from './restaurar-senha.page';

describe('RestaurarSenhaPage', () => {
  let component: RestaurarSenhaPage;
  let fixture: ComponentFixture<RestaurarSenhaPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(RestaurarSenhaPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
