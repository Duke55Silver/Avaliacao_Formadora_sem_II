import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AutheticationService } from 'src/app/authetication.service';

@Component({
  selector: 'app-restaurar-senha',
  templateUrl: './restaurar-senha.page.html',
  styleUrls: ['./restaurar-senha.page.scss'],
})
export class RestaurarSenhaPage implements OnInit {
  email:any
  constructor(public rota: Router, public authService:AutheticationService) { }

  ngOnInit() {
  }

  async restaurarsenha(){
    this.authService.restaurarsenha(this.email).then(()=>{
    console.log('Link para restaura a senha foi enviado!')
    this.rota.navigate(['/login'])
    }
    ).catch((error) =>{
      console.log(error);
    })
  }

}
