import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoadingController } from '@ionic/angular';
import { Router } from '@angular/router';
import { AutheticationService } from 'src/app/authetication.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {
  loginForm: FormGroup;
  emailnaoexiste: string = '';

  constructor(
    public rota: Router, 
    public formBuilder: FormBuilder, 
    public carregarcontroles: LoadingController, 
    public authService: AutheticationService
  ) { }

  ngOnInit() {
    this.loginForm = this.formBuilder.group({
      email: ['', [
        Validators.required,
        Validators.email,
        Validators.pattern("[a-z0-9._%+\-]+@[a-z0-9.\-]+\.[a-z]{2,}$")
      ]],
      inserirsenha: ['', [
        Validators.required,
        Validators.pattern("(?=.*\d)(?=.*[a-z])(?=.*[0-8])(?=.*[A-Z]).{8,}")
      ]]
    });
  }

  get errorControl() {
    return this.loginForm?.controls;
  }

  async login() {
    if (!this.loginForm.valid) {
      console.log('Por favor, forneça valores corretos!');
      return;
    }

    const loading = await this.carregarcontroles.create();
    await loading.present();

    try {
      const user = await this.authService.logindousuario(
        this.loginForm.value.email,
        this.loginForm.value.inserirsenha
      );

      if (user) {
        await loading.dismiss();
        this.rota.navigate(['/home']);
      } else {
        console.log('Falha ao logar usuário.');
        await loading.dismiss();
      }
    } catch (firebaseError) {
      await loading.dismiss();
      this.emailnaoexiste = this.getFirebaseErrorMessage(firebaseError);
      console.error('Erro ao logar:', firebaseError);
    }
  }

  getFirebaseErrorMessage(firebaseError: any): string {
    switch (firebaseError.code) {
      case 'auth/user-not-found':
        return 'O email não está registrado.';
      case 'auth/wrong-password':
        return 'A senha está incorreta.';
      default:
        return 'Ocorreu um erro inesperado. Tente novamente.';
    }
  }
}

