import { Component } from '@angular/core';
import { AutheticationService } from '../authetication.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
  user:any
  constructor(public rota: Router, public authService:AutheticationService) {
    this.user = authService.perfil()
  }

  async deslogar(){
    this.authService.deslogar().then(()=>{
      this.rota.navigate(['/landing'])
    }).catch((error)=>{
      console.log(error);
    })
  }

}
