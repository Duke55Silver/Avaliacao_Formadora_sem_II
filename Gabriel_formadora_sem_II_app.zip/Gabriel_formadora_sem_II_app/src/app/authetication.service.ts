import { Injectable } from '@angular/core';
import firebase from 'firebase/compat/app';
import { AngularFireAuth } from '@angular/fire/compat/auth';

@Injectable({
  providedIn: 'root'
})
export class AutheticationService {

  constructor(public ngFireAuth: AngularFireAuth) { }

  async cadastrar(email:string,password:string){
    return await this.ngFireAuth.createUserWithEmailAndPassword(email,password)
  }

  async logindousuario(email:string,password:string){
    return await this.ngFireAuth.signInWithEmailAndPassword(email,password)
  }

   async deslogar(){
    return await this.ngFireAuth.signOut()
  }

 async restaurarsenha(email:string){
    return await this.ngFireAuth.sendPasswordResetEmail(email)
  }

  async perfil(){
    return await this.ngFireAuth.currentUser
  }
}
